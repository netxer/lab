"""
TTL helpers — parse Go-style duration strings and compute expiry times.
"""

from datetime import datetime, timedelta, timezone
import re

_DURATION_RE = re.compile(r"^(?:(\d+)h)?(?:(\d+)m)?(?:(\d+)s)?$")


def parse_duration(s: str) -> timedelta:
    """Parse '4h30m' / '90m' / '2h' into a timedelta. Raises on bad input."""
    if not s:
        raise ValueError("empty duration string")
    m = _DURATION_RE.match(s.strip())
    if not m or not any(m.groups()):
        raise ValueError(f"invalid duration: {s!r}")
    hours = int(m.group(1) or 0)
    minutes = int(m.group(2) or 0)
    seconds = int(m.group(3) or 0)
    return timedelta(hours=hours, minutes=minutes, seconds=seconds)


def compute_expiry(ttl: str, started_at: datetime | None = None) -> datetime:
    """started_at + ttl. Defaults started_at to now()."""
    start = started_at or datetime.now(timezone.utc)
    return start + parse_duration(ttl)


def now_utc() -> datetime:
    return datetime.now(timezone.utc)


def parse_iso(s: str) -> datetime:
    """Parse ISO-8601 timestamp, tolerating both Z and +00:00 suffixes."""
    return datetime.fromisoformat(s.replace("Z", "+00:00"))


def isoformat(dt: datetime) -> str:
    """Emit a stable Z-suffixed ISO-8601 string."""
    return dt.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")
